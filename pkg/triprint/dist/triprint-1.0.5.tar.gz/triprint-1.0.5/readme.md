This package can be used for getting desired number of row star traiangle in up or down direction by giving an input for the desired number of rows.
# Use
For example if you want to get a 5 row star triangle in upward direction. Then you can simply code it as,

import triprint

triprint.pstar(5,1)

# First input will give the number of rows and second input is the boolean 0 or 1, 0 for down triangle and 1 for upper triangle.

# Attribute  
pstar('Number of rows in int','0 or 1')  # For printing triangles made up of '*'

phash('Number of rows in int','0 or 1')  # For printing triangles made up of '#

pdoller('Number of rows in int','0 or 1')  # For printing triangles made up of '$'

pat('Number of rows in int','0 or 1')  # For printing triangles made up of '@'