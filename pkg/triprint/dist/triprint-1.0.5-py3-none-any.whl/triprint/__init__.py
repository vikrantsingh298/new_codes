def pstar(n,c):


   for i in range(1,n+1):

      if bool(c)==True:
        print("*"*i)

      else:
        print("*"*(n+1-i))  

def phash(n,c):


   for i in range(1,n+1):

      if bool(c)==True:
        print("*"*i)

      else:
        print("#"*(n+1-i))  

def pdoller(n,c):


   for i in range(1,n+1):

      if bool(c)==True:
        print("$"*i)

      else:
        print("$"*(n+1-i))  

def pat(n,c):


   for i in range(1,n+1):

      if bool(c)==True:
        print("@"*i)

      else:
        print("@"*(n+1-i))  


                             


   

