
# Use
This package can be used for getting an output audio for the given text input.

# Syntax

import packagevikrant as pv

pv.speak("Hello World")

# Attributes
speak() -> Convert the input text into audio.

add()   -> Addition of two Numbers.